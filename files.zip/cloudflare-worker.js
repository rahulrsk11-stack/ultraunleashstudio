/**
 * Ultra Unleash Studio — Cloudflare Worker
 * Secure proxy for Anthropic API + form/booking storage
 *
 * DEPLOY STEPS:
 * 1. Go to https://workers.cloudflare.com and create a new Worker
 * 2. Paste this entire file into the editor
 * 3. Go to Settings → Variables → Add secret: ANTHROPIC_API_KEY = sk-ant-...
 * 4. Save & Deploy — you'll get a URL like: https://ultra-unleash-agent.YOUR_NAME.workers.dev
 * 5. Put that URL in your chat widget (replace WORKER_URL)
 */

export default {
  async fetch(request, env) {

    // ── CORS headers (allow your website domain in production) ──
    const CORS = {
      "Access-Control-Allow-Origin": "*",           // Change to "https://ultra-unleash-studio-eiwm.bolt.host" in production
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS });
    }

    if (request.method !== "POST") {
      return new Response("Method not allowed", { status: 405, headers: CORS });
    }

    const url = new URL(request.url);

    // ── ROUTE: /chat — proxy to Anthropic ──────────────────────
    if (url.pathname === "/chat") {
      return handleChat(request, env, CORS);
    }

    // ── ROUTE: /contact — save contact form submission ─────────
    if (url.pathname === "/contact") {
      return handleContact(request, env, CORS);
    }

    // ── ROUTE: /booking — save appointment booking ─────────────
    if (url.pathname === "/booking") {
      return handleBooking(request, env, CORS);
    }

    return new Response("Not found", { status: 404, headers: CORS });
  }
};

// ── CHAT PROXY ─────────────────────────────────────────────────
async function handleChat(request, env, CORS) {
  try {
    const body = await request.json();

    // Basic validation
    if (!body.messages || !Array.isArray(body.messages)) {
      return json({ error: "Invalid request" }, 400, CORS);
    }

    // Limit history to last 20 messages to control costs
    const messages = body.messages.slice(-20);

    const SYSTEM_PROMPT = `You are the friendly, knowledgeable assistant for Ultra Unleash Studio, an architecture and engineering design firm based in Chhatrapati Sambhajinagar (Aurangabad), Maharashtra, India.

About the studio:
- Specializes in: Architecture design, Civil engineering, Interior design, Photorealistic 3D visualization & rendering
- Location: Chhatrapati Sambhajinagar, Maharashtra
- Vision: "Transforming ideas into timeless spaces through innovative architecture and realistic visualization"
- They work on residential, commercial, and institutional projects

Your role:
- Help potential clients understand services, process, and how to get started
- Answer questions about architecture, interior design, engineering services
- Explain what 3D visualization is and its benefits
- Guide users on how to initiate a project consultation
- Be professional yet warm, concise yet thorough

When a user seems ready to connect, suggest they fill the Contact form or Book an Appointment — you can say "I can help you do that right here in the chat."

Tone: Sophisticated, helpful, confident. Keep answers to 2–4 sentences unless more detail is needed.

If asked for pricing, say costs vary by project scope and invite them to book a free consultation.`;

    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages,
      }),
    });

    const data = await anthropicRes.json();
    return json(data, 200, CORS);

  } catch (err) {
    return json({ error: "Server error", detail: err.message }, 500, CORS);
  }
}

// ── CONTACT FORM ───────────────────────────────────────────────
async function handleContact(request, env, CORS) {
  try {
    const { name, email, phone, message, projectType } = await request.json();

    if (!name || !email || !message) {
      return json({ error: "Name, email, and message are required." }, 400, CORS);
    }

    // Store in KV (bind a KV namespace called LEADS in your Worker settings)
    if (env.LEADS) {
      const id = `contact_${Date.now()}`;
      await env.LEADS.put(id, JSON.stringify({
        type: "contact",
        name, email, phone, message, projectType,
        submittedAt: new Date().toISOString(),
      }));
    }

    // Optional: send email via Cloudflare Email Routing or a webhook
    // await notifyEmail(env, { name, email, phone, message, projectType });

    return json({ success: true, message: "Thank you! We'll be in touch within 24 hours." }, 200, CORS);

  } catch (err) {
    return json({ error: "Could not save contact form.", detail: err.message }, 500, CORS);
  }
}

// ── APPOINTMENT BOOKING ────────────────────────────────────────
async function handleBooking(request, env, CORS) {
  try {
    const { name, email, phone, date, time, service, notes } = await request.json();

    if (!name || !email || !date || !time) {
      return json({ error: "Name, email, date, and time are required." }, 400, CORS);
    }

    // Store in KV
    if (env.LEADS) {
      const id = `booking_${Date.now()}`;
      await env.LEADS.put(id, JSON.stringify({
        type: "booking",
        name, email, phone, date, time, service, notes,
        submittedAt: new Date().toISOString(),
      }));
    }

    return json({
      success: true,
      message: `Appointment confirmed for ${date} at ${time}. We'll send a confirmation to ${email}.`,
    }, 200, CORS);

  } catch (err) {
    return json({ error: "Could not save booking.", detail: err.message }, 500, CORS);
  }
}

// ── Helper ─────────────────────────────────────────────────────
function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...extraHeaders },
  });
}
